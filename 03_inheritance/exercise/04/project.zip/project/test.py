from project.sport_car import SportCar
from project.family_car import FamilyCar
from project.cross_motorcycle import CrossMotorcycle
from project.race_motorcycle import RaceMotorcycle
from project.vehicle import Vehicle

vehicle = Vehicle(50, 150)
print(Vehicle.DEFAULT_FUEL_CONSUMPTION)
print(FamilyCar.DEFAULT_FUEL_CONSUMPTION)
print(vehicle.fuel)
print(vehicle.horse_power)
print(vehicle.fuel_consumption)
vehicle.drive(100)
print(vehicle.fuel)
family_car = FamilyCar(150, 150)
family_car.drive(50)
print(family_car.fuel)
family_car.drive(50)
print(family_car.fuel)
print(family_car.__class__.__bases__[0].__name__)

sport_car = SportCar(150, 300)
sport_car.drive(500)
print(sport_car.fuel)
print(sport_car.__class__.__name__)

race_motorcycle = RaceMotorcycle(5, 300)
race_motorcycle.drive(50)
print(race_motorcycle.fuel)